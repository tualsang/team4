/**
 *  Cart Logic Tests
 * - Add item to cart
 * - Remove item from cart
 * - Calculate total amount in cart
 */

const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const bcrypt = require('bcryptjs');
const User = require('../models/userModel');
const Item = require('../models/itemModel');

let mongoServer;

beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri = mongoServer.getUri();
  await mongoose.connect(uri);
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongoServer.stop();
});

beforeEach(async () => {
  await User.deleteMany({});
  await Item.deleteMany({});
});

test('Test 1: Add item to cart', async () => {
  const user = new User({
    firstName: 'CartAdd',
    lastName: 'User',
    email: 'cartadd@test.com',
    password: await bcrypt.hash('pass123', 10),
  });
  await user.save();

  const item = new Item({
    title: 'Item 1',
    condition: 'New',
    price: 50,
    category: 'Books',
    seller: user._id,
  });
  await item.save();

  user.cart.push({ item: item._id });
  await user.save();

  const updatedUser = await User.findById(user._id);
  expect(updatedUser.cart).toHaveLength(1);
  expect(updatedUser.cart[0].item.toString()).toBe(item._id.toString());
});

test('Test 2: Remove item from cart', async () => {
  const user = new User({
    firstName: 'CartRemove',
    lastName: 'User',
    email: 'cartremove@test.com',
    password: await bcrypt.hash('pass123', 10),
  });
  await user.save();

  const item = new Item({
    title: 'Item 2',
    condition: 'Used',
    price: 30,
    category: 'Clothing',
    seller: user._id,
  });
  await item.save();

  user.cart.push({ item: item._id });
  await user.save();

  // Remove from cart
  user.cart = user.cart.filter(entry => entry.item.toString() !== item._id.toString());
  await user.save();

  const updatedUser = await User.findById(user._id);
  expect(updatedUser.cart).toHaveLength(0);
});

test('Test 3: Add multiple items and calculate total cost', async () => {
  const user = new User({
    firstName: 'CartTotal',
    lastName: 'User',
    email: 'carttotal@test.com',
    password: await bcrypt.hash('pass123', 10),
  });
  await user.save();

  const item1 = new Item({
    title: 'Item A',
    condition: 'New',
    price: 40,
    category: 'Electronics',
    seller: user._id,
  });
  const item2 = new Item({
    title: 'Item B',
    condition: 'New',
    price: 60,
    category: 'Electronics',
    seller: user._id,
  });

  await item1.save();
  await item2.save();

  user.cart.push({ item: item1._id }, { item: item2._id });
  await user.save();

  // Populate items and calculate total
  const populatedUser = await User.findById(user._id).populate('cart.item');
  const total = populatedUser.cart.reduce((sum, entry) => sum + entry.item.price, 0);

  expect(populatedUser.cart).toHaveLength(2);
  expect(total).toBe(100);
});
