const User = require('../models/userModel');

const express = require('express');
const userController = require('../controllers/userController');
const { isLoggedIn, isGuest } = require('../middlewares/auth');
const router = express.Router();

router.get('/new', isGuest, userController.new);
router.post('/', isGuest, userController.create);
router.get('/login', isGuest, userController.getUserLogin);
router.post('/login', isGuest, userController.login);
router.get('/profile', isLoggedIn, userController.profile);
router.get('/logout', isLoggedIn, userController.logout);
router.post('/cart/:id/add', isLoggedIn, userController.addToCart);
router.post('/cart/:id/remove', isLoggedIn, userController.removeFromCart);
router.post('/cart/purchase', isLoggedIn, userController.purchaseItems);
router.get('/cart', isLoggedIn, userController.viewCart);

// router.post('/convert-usd-to-coins', isLoggedIn, userController.convertUsdToCoins);
router.post('/convert-usd-to-coins-credit-card', isLoggedIn, async (req, res, next) => {
    console.log('Route called');
    console.log(req.body);
    try {
      const userId = req.session.user;
      console.log('User ID:', userId);
      const usdAmount = req.body.usdAmount;
      console.log('USD Amount:', usdAmount);
      const cardNumber = req.body.cardNumber;
      const cardName = req.body.cardName;
      const expirationMonth = req.body.expirationMonth;
      const expirationYear = req.body.expirationYear;
      const cvc = req.body.cvc;
  
      if (!usdAmount || usdAmount <= 0) {
        console.log('Invalid amount');
        req.flash('error', 'Invalid amount');
        return res.redirect('/users/profile');
      }
  
      if (!cardNumber ||!cardName ||!expirationMonth ||!expirationYear ||!cvc) {
        console.log('Please fill in all credit card information');
        req.flash('error', 'Please fill in all credit card information');
        return res.redirect('/users/profile');
      }
  
      const coinAmount = usdAmount * 100; // 1 USD = 100 coins
      console.log('Coin Amount:', coinAmount);
  
      const user = await User.findById(userId);
      console.log('User found:', user);
      user.coins += coinAmount;
      await user.save();
      console.log('Coins added to user balance');
  
      req.flash('success', `Converted $${usdAmount} to ${coinAmount} coins`);
      res.redirect('/users/profile');
    } catch (err) {
      console.log('Error:', err);
      req.flash('error', 'Error converting USD to coins');
      res.redirect('/users/profile');
    }
  });

module.exports = router;
