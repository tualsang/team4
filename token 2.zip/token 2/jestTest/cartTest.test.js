const React = require('react');
const { render, fireEvent, waitFor } = require('@testing-library/react');
const Cart = require('./Cart');
const { rest } = require('msw');
const { setupServer } = require('msw/node');

const server = setupServer(
  rest.get('/api/cart', (req, res, ctx) => {
    return res(ctx.json([
      {
        _id: '123',
        title: 'Product 1',
        price: 10.99,
        image: 'https://example.com/product1.jpg',
      },
      {
        _id: '456',
        title: 'Product 2',
        price: 9.99,
        image: 'https://example.com/product2.jpg',
      },
    ]));
  }),
  rest.post('/api/cart/:id/remove', (req, res, ctx) => {
    return res(ctx.status(200));
  }),
  rest.post('/api/cart/purchase', (req, res, ctx) => {
    return res(ctx.status(200));
  }),
);

describe('Cart component', () => {
  afterEach(() => {
    server.resetHandlers();
  });

  afterAll(() => {
    server.close();
  });

  it('renders cart items', async () => {
    try {
      const { getByText, getAllByRole } = render(<Cart />);
      await waitFor(() => expect(getByText('Product 1')).toBeInTheDocument());
      await waitFor(() => expect(getByText('Product 2')).toBeInTheDocument());
      const cartItems = getAllByRole('listitem');
      expect(cartItems).toHaveLength(2);
    } catch (error) {
      expect(error).toBeUndefined();
    }
  });

  it('renders total price', async () => {
    try {
      const { getByText } = render(<Cart />);
      await waitFor(() => expect(getByText('Total Price: $20.98')).toBeInTheDocument());
    } catch (error) {
      expect(error).toBeUndefined();
    }
  });

  it('removes item from cart', async () => {
    try {
      const { getByText, getByRole } = render(<Cart />);
      await waitFor(() => expect(getByText('Product 1')).toBeInTheDocument());
      const removeButton = getByRole('button', { name: 'Remove Product 1 from cart' });
      fireEvent.click(removeButton);
      await waitFor(() => expect(getByText('Product 1')).not.toBeInTheDocument());
    } catch (error) {
      expect(error).toBeUndefined();
    }
  });

  it('purchases cart items', async () => {
    try {
      const { getByRole } = render(<Cart />);
      const purchaseButton = getByRole('button', { name: 'Purchase' });
      fireEvent.click(purchaseButton);
      await waitFor(() => expect(server.handlers[2].ctx.status).toBe(200));
    } catch (error) {
      expect(error).toBeUndefined();
    }
  });

  it('renders empty cart message', async () => {
    server.use(
      rest.get('/api/cart', (req, res, ctx) => {
        return res(ctx.status(200), ctx.json([]));
      }),
    );
    try {
      const { getByText } = render(<Cart />);
      await waitFor(() => expect(getByText('Your cart is empty.')).toBeInTheDocument());
    } catch (error) {
      expect(error).toBeUndefined();
    }
  });
});