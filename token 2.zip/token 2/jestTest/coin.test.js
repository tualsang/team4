/**
 * This test suite verifies the core logic of our platform-specific coin transaction system.
 *
 *  Test 1: "should deduct coins from buyer and credit seller on purchase"
 *    - Simulates a complete transaction:
 *      - A buyer with 50 coins purchases an item worth 20 coins.
 *      - After purchase:
 *          - Buyer's coins decrease by 20 → becomes 30.
 *          - Seller’s coins increase by 20 → becomes 20.
 *          - Buyer's cart is cleared.
 *      - This ensures coin deduction and transfer between buyer and seller is accurate.
 *
 *  Test 2: "should fail to purchase if buyer does not have enough coins"
 *    - Simulates a failed transaction due to insufficient coins:
 *      - A buyer with only 5 coins tries to buy an item worth 20 coins.
 *      - The purchase is blocked.
 *      - The buyer’s coin balance and cart remain unchanged.
 *      - This ensures secure purchase logic and error handling is enforced.
 *
 * These tests confirm the platform's token economy system works securely, mimicking a digital wallet.
 */


const request = require('supertest');
const app = require('../app');
const mongoose = require('mongoose');
const User = require('../models/userModel');
const Item = require('../models/itemModel');

let buyerAgent, sellerId, buyerId, itemId;

beforeAll(async () => {
  await mongoose.connect('mongodb://127.0.0.1:27017/test-marketplace');
  await User.deleteMany({});
  await Item.deleteMany({});

  // Create seller
  const seller = new User({
    firstName: 'Seller',
    lastName: 'Test',
    email: 'seller@test.com',
    password: 'password123',
    coins: 0
  });
  await seller.save();
  sellerId = seller._id;

  // Create item
  const item = new Item({
    title: 'Test Item',
    condition: 'New',
    price: 20,
    category: 'Electronics',
    seller: sellerId
  });
  await item.save();
  itemId = item._id;

  // Create buyer
  const buyer = new User({
    firstName: 'Buyer',
    lastName: 'Test',
    email: 'buyer@test.com',
    password: 'password123',
    coins: 50,
    cart: [{ item: itemId }]
  });
  await buyer.save();
  buyerId = buyer._id;

  // Log in buyer using Supertest agent
  buyerAgent = request.agent(app);
  await buyerAgent
    .post('/users/login')
    .type('form')
    .send({ email: 'buyer@test.com', password: 'password123' });
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe('Coin-based transactions', () => {
  it('should deduct coins from buyer and credit seller on purchase', async () => {
    const res = await buyerAgent.post('/users/cart/purchase');
    expect(res.statusCode).toBe(302);

    const updatedBuyer = await User.findById(buyerId);
    const updatedSeller = await User.findById(sellerId);

    expect(updatedBuyer.coins).toBe(30); // 50 - 20
    expect(updatedBuyer.cart.length).toBe(0);
    expect(updatedSeller.coins).toBe(20); // Seller earned 20
  });

  it('should fail to purchase if buyer does not have enough coins', async () => {
    const lowBuyer = new User({
      firstName: 'Low',
      lastName: 'Coins',
      email: 'low@test.com',
      password: 'password123',
      coins: 5,
      cart: [{ item: itemId }]
    });
    await lowBuyer.save();

    const lowBuyerAgent = request.agent(app);
    await lowBuyerAgent
      .post('/users/login')
      .type('form')
      .send({ email: 'low@test.com', password: 'password123' });

    const res = await lowBuyerAgent.post('/users/cart/purchase');

    const updated = await User.findOne({ email: 'low@test.com' });
    expect(updated.coins).toBe(5); // Coins unchanged
    expect(updated.cart.length).toBe(1); // Cart not cleared
  });
});
