jest.setTimeout(30000)
const mongoose = require('mongoose')
const { MongoMemoryServer } = require('mongodb-memory-server')
const User = require('../models/userModel')

let mongoServer

const voidCoins = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id)
    if (!user) {
      return res.status(404).json({ error: 'User not found' })
    }
    user.coins = 0
    await user.save()
    res.status(200).json({ success: true })
  } catch (err) {
    next(err)
  }
}

describe('Voiding of Stolen Coins', () => {
  let testUser
  beforeAll(async () => {
    mongoServer = await MongoMemoryServer.create()
    const uri = mongoServer.getUri()
    await mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
  })
  afterAll(async () => {
    await mongoose.disconnect()
    if (mongoServer) {
      await mongoServer.stop()
    }
  })
  beforeEach(async () => {
    testUser = await new User({
      firstName: 'Test',
      lastName: 'User',
      email: 'testuser@example.com',
      password: 'testpassword',
      coins: 500
    }).save()
  })
  afterEach(async () => {
    await User.deleteMany({})
  })
  it('should set coins to 0 for the voided account', async () => {
    const req = { params: { id: testUser._id } }
    let statusCode
    const res = {
      status: (code) => { statusCode = code; return res },
      json: jest.fn()
    }
    const next = jest.fn()
    await voidCoins(req, res, next)
    expect(statusCode).toBe(200)
    const updatedUser = await User.findById(testUser._id)
    expect(updatedUser.coins).toBe(0)
  })
})
