const mongoose = require('mongoose');
const Review = require('../models/reviewModel');
const Item = require('../models/itemModel');
const User = require('../models/userModel');

exports.createReview = async (req, res, next) => {
  const userId = req.session.user;
  const itemId = req.params.id;
  const { rating, comment } = req.body;

  try {
    const user = await User.findById(userId);
    const item = await Item.findById(itemId);

    if (!user || !item) {
      return res.status(404).send('User or Item not found.');
    }

    const alreadyReviewed = await Review.findOne({
      user: userId,
      item: itemId
    });

    if (alreadyReviewed) {
      req.flash('error', 'You have already submitted a review for this item.');
      return res.redirect(`/items/${itemId}`);
    }

    const hasPurchased = user.purchasedItems && user.purchasedItems.some(p =>
      (p.item || p).toString() === itemId
    );



    if (!hasPurchased) {
      req.flash('error', 'Only buyers who purchased this item can leave a review.');
      return res.redirect(`/items/${itemId}`);
    }

    await Review.create({
      user: userId,
      item: itemId,
      rating: parseInt(rating),
      comment: comment.trim()
    });

    req.flash('success', 'Review submitted.');
    res.redirect(`/items/${itemId}`);
  } catch (err) {
    next(err);
  }
};

exports.deleteReview = async (req, res, next) => {
  const { id: itemId, reviewId } = req.params;
  const userId = req.session.user;

  try {
    const review = await Review.findById(reviewId);
    if (!review || review.user.toString() !== userId.toString()) {
      req.flash('error', 'You can only delete your own review.');
      return res.redirect(`/items/${itemId}`);
    }

    await Review.findByIdAndDelete(reviewId);

    await Item.findByIdAndUpdate(itemId, {
      $pull: { reviews: reviewId }
    });

    const remainingReviews = await Review.find({ item: itemId });
    const avgRating = remainingReviews.length
      ? remainingReviews.reduce((sum, r) => sum + r.rating, 0) / remainingReviews.length
      : null;

    await Item.findByIdAndUpdate(itemId, {
      averageRating: avgRating
    });

    req.flash('success', 'Review deleted.');
    res.redirect(`/items/${itemId}`);
  } catch (err) {
    next(err);
  }
};
