const express = require('express');
const userController = require('../controllers/userController');
const { isLoggedIn, isGuest } = require('../middlewares/auth');
const router = express.Router();

router.get('/new', isGuest, userController.new);
router.post('/', isGuest, userController.create);
router.get('/login', isGuest, userController.getUserLogin);
router.post('/login', isGuest, userController.login);
router.get('/profile', isLoggedIn, userController.profile);
router.get('/logout', isLoggedIn, userController.logout);
// Add to Cart
router.post('/cart/:id/add', isLoggedIn, userController.addToCart);

// Remove from Cart
router.post('/cart/:id/remove', isLoggedIn, userController.removeFromCart);

// Purchase Items
router.post('/cart/purchase', isLoggedIn, userController.purchaseItems);

// View Cart
router.get('/cart', isLoggedIn, userController.viewCart);

module.exports = router;

module.exports = router;
