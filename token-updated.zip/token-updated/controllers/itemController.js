const Item = require('../models/itemModel');
const User = require('../models/userModel');
const Review = require('../models/reviewModel');
const multer = require('multer');
const path = require('path');
const { body, validationResult } = require('express-validator');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/uploads');
  },
  filename: function (req, file, cb) {
    const sanitizedFilename = file.originalname.replace(/[^a-zA-Z0-9.]/g, '-');
    cb(null, Date.now() + '-' + sanitizedFilename);
  }
});

const upload = multer({ storage: storage });

exports.getItems = (req, res, next) => {
  const { keyword, category, condition, sort } = req.query;
  let query = {};

  if (keyword) query.title = { $regex: keyword, $options: 'i' };
  if (category && category !== 'All') query.category = category;
  if (condition) query.condition = condition;

  const sortOption = sort === 'desc' ? { price: -1 } : { price: 1 };

  Item.find(query)
    .populate('seller', 'firstName lastName')
    .sort(sortOption)
    .then(async (items) => {
      for (let item of items) {
        const reviews = await Review.find({ item: item._id });
        const totalRating = reviews.reduce((acc, review) => acc + review.rating, 0);
        item.avgRating = reviews.length ? (totalRating / reviews.length).toFixed(1) : null;
      }

      res.render('gpu/items', {
        items,
        searchKeyword: keyword || '',
        selectedCategory: category || 'All',
        selectedCondition: condition || '',
        sortOrder: sort || 'asc',
      });
    })
    .catch(err => next(err));
};


exports.getItem = async (req, res, next) => {
  const id = req.params.id;
  const userId = req.session.user;

  try {
    const item = await Item.findById(id).populate('seller', 'firstName lastName');
    if (!item) {
      const err = new Error(`Cannot find an item with id ${id}`);
      err.status = 404;
      return next(err);
    }

    const reviews = await Review.find({ item: id }).populate('user', 'firstName lastName');

    let hasPurchased = false;
    let isOwner = false;
    let alreadyReviewed = false;

    if (userId) {
      const user = await User.findById(userId);

      if (user && user.purchasedItems) {
        hasPurchased = user.purchasedItems.some(p => {
          const itemIdStr = p.item ? p.item.toString() : p.toString();
          return itemIdStr === id;
        });
      }

      isOwner = item.seller._id.toString() === userId.toString();

      alreadyReviewed = reviews.some(r => r.user && r.user._id.toString() === userId.toString());
    }

    res.render('gpu/item', {
      item,
      reviews,
      user: userId,
      hasPurchased,
      isOwner,
      alreadyReviewed,
      successMessages: req.flash('success'),
      errorMessages: req.flash('error')
    });
  } catch (err) {
    next(err);
  }
};

exports.createItemForm = (req, res) => {
  res.render('gpu/new', { errors: {}, item: {} });
};

exports.createItem = [
  upload.single('image'),
  body('title').trim().notEmpty().withMessage('Title is required').escape(),
  body('condition')
    .trim()
    .notEmpty().withMessage('Condition is required')
    .isIn(['New', 'Used', 'Refurbished', 'Like New', 'For Parts']).withMessage('Invalid condition')
    .escape(),
  body('category')
    .trim()
    .notEmpty().withMessage('Category is required')
    .isIn(['Electronics', 'Books', 'Clothing', 'Home', 'Other']).withMessage('Invalid category')
    .escape(),
  body('price')
    .trim()
    .notEmpty().withMessage('Price is required')
    .isFloat({ min: 0.01 }).withMessage('Price must be at least 0.01'),
  body('details').trim().escape(),
  async (req, res, next) => {
    const errors = validationResult(req);
    const itemData = {
      ...req.body,
      seller: req.session.user,
      image: req.file ? '/uploads/' + req.file.filename : undefined
    };

    if (!errors.isEmpty()) {
      return res.render('gpu/new', { errors: errors.mapped(), item: itemData });
    }

    try {
      const newItem = new Item(itemData);
      await newItem.save();

      const user = await User.findById(req.session.user);
      const listedItemsCount = await Item.countDocuments({ seller: user._id });

      if (user && listedItemsCount <= 2) {
        user.coins += 5;
        await user.save();
        req.flash('success', 'Item created successfully. You just earned 5 coins!');
      } else {
        req.flash('success', 'Item created successfully.');
      }

      res.redirect('/items');
    } catch (err) {
      if (err.name === 'ValidationError') {
        err.status = 400;
        res.render('gpu/new', { errors: err.errors, item: itemData });
      } else {
        next(err);
      }
    }
  }
];

exports.editItem = (req, res, next) => {
  const id = req.params.id;

  Item.findById(id)
    .then(item => {
      if (item) {
        res.render('gpu/edit', { item });
      } else {
        const err = new Error(`Cannot find an item with id ${id}`);
        err.status = 404;
        next(err);
      }
    })
    .catch(err => next(err));
};

exports.updateItem = [
  upload.single('image'),
  body('title').trim().notEmpty().withMessage('Title is required').escape(),
  body('condition')
    .trim()
    .notEmpty().withMessage('Condition is required')
    .isIn(['New', 'Used', 'Refurbished']).withMessage('Invalid condition')
    .escape(),
  body('price')
    .trim()
    .notEmpty().withMessage('Price is required')
    .isCurrency().withMessage('Please enter a valid price'),
  body('details').optional().trim().escape(),
  (req, res, next) => {
    const errors = validationResult(req);
    const id = req.params.id;
    const itemData = {
      ...req.body,
      image: req.file ? '/uploads/' + req.file.filename : undefined
    };

    if (!errors.isEmpty()) {
      return res.render('gpu/edit', { errors: errors.mapped(), item: { _id: id, ...itemData } });
    }

    Item.findByIdAndUpdate(id, itemData, { new: true, runValidators: true })
      .then(item => {
        if (item) {
          req.flash('success', 'Item updated successfully.');
          res.redirect(`/items/${id}`);
        } else {
          const err = new Error(`Cannot find an item with id ${id}`);
          err.status = 404;
          next(err);
        }
      })
      .catch(err => {
        if (err.name === 'ValidationError') {
          res.render('gpu/edit', { errors: err.errors, item: { _id: id, ...itemData } });
        } else {
          next(err);
        }
      });
  }
];

exports.deleteItem = (req, res, next) => {
  const id = req.params.id;

  Item.findByIdAndDelete(id)
    .then(item => {
      if (item) {
        req.flash('success', 'Item deleted successfully.');
        res.redirect('/items');
      } else {
        const err = new Error(`Cannot find an item with id ${id}`);
        err.status = 404;
        next(err);
      }
    })
    .catch(err => next(err));
};
