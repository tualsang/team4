jest.setTimeout(30000)
const mongoose = require('mongoose')
const { MongoMemoryServer } = require('mongodb-memory-server')
const User = require('../models/userModel')

let mongoServer

const issueRefund = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id)
    if (!user) {
      return res.status(404).json({ error: 'User not found' })
    }
    const refundAmount = Number(req.body.amount) || 0
    user.coins += refundAmount
    await user.save()
    res.status(200).json({ success: true })
  } catch (err) {
    next(err)
  }
}

describe('Issuance of Refund in Platform Coins', () => {
  let testUser
  beforeAll(async () => {
    mongoServer = await MongoMemoryServer.create()
    const uri = mongoServer.getUri()
    await mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
  })
  afterAll(async () => {
    await mongoose.disconnect()
    if (mongoServer) {
      await mongoServer.stop()
    }
  })
  beforeEach(async () => {
    testUser = await new User({
      firstName: 'Refund',
      lastName: 'Tester',
      email: 'refundtester@example.com',
      password: 'testpassword',
      coins: 100
    }).save()
  })
  afterEach(async () => {
    await User.deleteMany({})
  })
  it('should increase coins by the refund amount for the refunded account', async () => {
    const refundAmount = 150
    const req = { params: { id: testUser._id }, body: { amount: refundAmount } }
    let statusCode
    const res = {
      status: (code) => { statusCode = code; return res },
      json: jest.fn()
    }
    const next = jest.fn()
    await issueRefund(req, res, next)
    expect(statusCode).toBe(200)
    const updatedUser = await User.findById(testUser._id)
    expect(updatedUser.coins).toBe(100 + refundAmount)
  })
})
