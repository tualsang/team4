const express = require('express');
const router = express.Router();
const reviewController = require('../controllers/reviewController');
const { isLoggedIn } = require('../middlewares/auth');

router.post('/items/:id/review', isLoggedIn, reviewController.createReview);
router.post('/items/:id/review/:reviewId/delete', isLoggedIn, reviewController.deleteReview);

module.exports = router;
